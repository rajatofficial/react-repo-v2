import React from "react";
import "./Footer.css";
const Footer = () => {

    return (
            <div className="footer">
                <p>Cox Automotive &nbsp; All Rights Reserved &copy; 2020</p>
            </div>
    )
}

export default Footer;